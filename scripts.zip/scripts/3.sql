WITH CustomerSpending AS (
    SELECT `Customer ID`, 
        ROUND(AVG(Total), 2) AS Avg_Spending
    FROM walmart
    GROUP BY `Customer ID`),
 SpendingStats AS (
    SELECT 
        AVG(Avg_Spending) AS Mean_Spending, 
        STDDEV(Avg_Spending) AS Std_Dev_Spending
    FROM CustomerSpending)
 SELECT 
    c.`Customer ID`, 
    c.Avg_Spending, 
    CASE 
        WHEN c.Avg_Spending >= (s.Mean_Spending + s.Std_Dev_Spending) THEN
 'High Spender'
        WHEN c.Avg_Spending <= (s.Mean_Spending - s.Std_Dev_Spending) THEN
 'Low Spender'
        ELSE 'Medium Spender'
    END AS Spending_Category
 FROM CustomerSpending c
 CROSS JOIN SpendingStats s
 ORDER BY c.Avg_Spending DESC;