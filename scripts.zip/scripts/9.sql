SELECT 
    `Customer ID`, 
    SUM(Total) AS Total_Sales
 FROM walmart
 GROUP BY `Customer ID`
 ORDER BY Total_Sales DESC
 LIMIT 5;