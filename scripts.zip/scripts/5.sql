WITH PaymentCount AS (
    SELECT City, Payment, 
        COUNT(*) AS Payment_Count,
        RANK() OVER (PARTITION BY City ORDER BY COUNT(*) DESC) AS
 Rank_Order
    FROM walmart
    GROUP BY City, Payment)
 SELECT 
    City, 
    Payment AS Most_Popular_Payment_Method, 
    Payment_Count
 FROM PaymentCount
 WHERE Rank_Order = 1;