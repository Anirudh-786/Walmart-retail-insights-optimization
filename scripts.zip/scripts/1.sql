use walmart;
WITH monthly_sales AS (
    SELECT Branch, DATE_FORMAT(Str_to_date(Date, '%d-%m-%y'),'%m-%Y') AS month,
        SUM(Total) AS total_sales
    FROM walmart
    GROUP BY Branch,month),
    growth_rate AS (
    SELECT 
        Branch,month,total_sales,
        LAG(total_sales) OVER (PARTITION BY Branch ORDER BY month) as
 prev_month_sales,
         ((total_sales - LAG(total_sales) OVER (PARTITION BY Branch ORDER BY month)) / 
           LAG(total_sales) OVER (PARTITION BY Branch ORDER BY month)) * 100 AS
 growth_rate
    FROM monthly_sales)
 SELECT 
    Branch,max(growth_rate) as max_growth_rate
 FROM growth_rate
 WHERE growth_rate IS NOT NULL
 GROUP BY Branch
 ORDER BY max_growth_rate DESC
 limit 1;