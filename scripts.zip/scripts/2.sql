WITH ProfitRank AS (
    SELECT 
        Branch, 
        `Product line` AS Product_Category, 
        SUM(`gross income`) AS Total_Profit,
        ROW_NUMBER() OVER (PARTITION BY Branch ORDER BY SUM(`gross income`)
 DESC) AS Ranking
    FROM walmart
    GROUP BY Branch, `Product line`
 )
 SELECT Branch, Product_Category, Total_Profit
 FROM ProfitRank
 WHERE Ranking = 1;