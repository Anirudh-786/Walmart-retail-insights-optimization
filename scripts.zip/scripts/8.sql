WITH past_data AS (
    SELECT `Customer ID`, 
        STR_TO_DATE(Date, '%d-%m-%Y') AS purchase_date 
    FROM walmart),
 ranked_data AS (
    SELECT `Customer ID`, purchase_date,
        LEAD(purchase_date) OVER (PARTITION BY `Customer ID` ORDER
 BY purchase_date) AS next_purchase_date
    FROM past_data),
 repeat_customers AS (
    SELECT `Customer ID`, purchase_date, next_purchase_date,
        DATEDIFF(next_purchase_date, purchase_date) AS days_between
    FROM ranked_data 
    WHERE next_purchase_date IS NOT NULL  
    AND DATEDIFF(next_purchase_date, purchase_date) <= 30  )
 SELECT `Customer ID`, 
    COUNT(*) AS Repeat_Count 
 FROM repeat_customers 
GROUP BY `Customer ID`
 ORDER BY Repeat_Count DESC;