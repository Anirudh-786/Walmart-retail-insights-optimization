SELECT
    Gender,
    DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m') AS Month,
    SUM(Total) AS Monthly_Sales
FROM
    walmart
GROUP BY
    Gender,
    DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m')
ORDER BY
    Month, Gender;
