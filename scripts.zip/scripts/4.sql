with average_sales as (
 select `product line`, avg(total) as avg_sales from
 walmart group by `product line`),
 anomalies as (
 select `invoice id`, `product line`, total, avg_sales, case
 when total > (avg_sales * 1.5) then 'High Anomaly'
 when total < (avg_sales * 0.5) then 'Low Anomaly'
 else 'Normal' 
end as anomaly_type from walmart join
 average_sales using (`product line`))
 select `invoice id`, `product line`, total, avg_sales,
 anomaly_type from anomalies;